var app = {
    // Application Constructor
    initialize: function() {
        this.bindEvents();
		
		window.AudioContext = window.AudioContext || window.webkitAudioContext;
		context = new AudioContext();

		console.log(context);

        myShakeEvent.start();
        window.addEventListener('shake', this.shakeHandler, false);

		this.updatePos();

    },
    // Bind Event Listeners
    //
    // Bind any events that are required on startup. Common events are:
    // 'load', 'deviceready', 'offline', and 'online'.
    bindEvents: function() {
        document.addEventListener('deviceready', this.onDeviceReady, false);
        $('.bufferResources').on('click',this.bufferResources);
        $('.play').on('click',this.playback);
        $('.updatePos').on('click',this.updatePos);
    },
    // deviceready Event Handler
    //
    // The scope of 'this' is the event. In order to call the 'receivedEvent'
    // function, we must explicitly call 'app.receivedEvent(...);'
    onDeviceReady: function() {
        app.receivedEvent('deviceready');
    },
    // Update DOM on a Received Event
    receivedEvent: function(id) {
        var parentElement = document.getElementById(id);
        var listeningElement = parentElement.querySelector('.listening');
        var receivedElement = parentElement.querySelector('.received');

        listeningElement.setAttribute('style', 'display:none;');
        receivedElement.setAttribute('style', 'display:block;');

    },
    // Buffer soundfiles
    bufferResources: function(event){

		bufferLoader = new BufferLoader(context, [
			'sounds/guitar_1.wav',
			'sounds/guitar_2.wav',
			'sounds/guitar_3.wav',
		], app.bufferFinish);

        bufferLoader.load();
        console.log(bufferLoader);

    },
    bufferFinish: function(bufferList){	
		console.log('finished Buffering');

    	for(var i = 0; i<bufferList.length; i++){
			/*sources[i] = context.createBufferSource();
			sources[i].buffer = bufferList[i];
			sources[i].connect(context.destination);*/
			console.log(bufferList[0]);
			myShakeInterval = parseInt(bufferList[0].duration * 1000);
			//sources[i] = bufferList[i];
    	}

		console.log('timer: ' + myShakeInterval);

		//app.shakeIntervalHandler();
   		myShakeTimer = setInterval(function(){ console.log('interval'); app.shakeIntervalHandler(); }, myShakeInterval);

   		console.log(myShakeTimer);


		$('.buffer').slideUp();
		$('.playback').slideDown().removeClass('hide');
    },
    playback: function(event){

    	var soundId = $(this).data('id');
    	//sources[soundId].start(0);
    	//
    	var startTime = context.currentTime;
    	app.playSound(bufferLoader.bufferList[soundId], startTime);
        console.log(bufferLoader.bufferList[soundId]);
    },
    // Geolocation
    updatePos: function(e){
        navigator.geolocation.getCurrentPosition(app.getLocation);
    },
    getLocation: function(location) {
        $('.geoposition .lat span').html(location.coords.latitude);
        $('.geoposition .lon span').html(location.coords.longitude);
        $('.geoposition .acc span').html(location.coords.accuracy);
    },
    shakeHandler: function(){
        shakeCounter += 1;
        $('.shakeCounter h2.shake span').html(shakeCounter);
    },
    shakeIntervalHandler: function(){
    	console.log('shakeIntervalHandler');
        $('.shakeCounter h2.interval span').html(shakeCounter);

		var id = '';
        if(shakeCounter <= 6){
        	id = 0;
        } else if(shakeCounter >= 7 && shakeCounter <= 15){
        	id = 1;
        } else {
        	id = 2;
        }
        console.log('shakes during interval: ' + shakeCounter);

		console.log('starting sound: ' + id);

        $('audio:eq('+id+')')[0].currentTime = 0;
        $('audio:eq('+id+')')[0].play();




		var startTime = context.currentTime;
    	app.playSound(bufferLoader.bufferList[id], startTime);
   		shakeCounter = 0;
    },
	playSound: function(buffer, time) {
		console.log(buffer);
		console.log(time);


		if(typeof playing.guitar != 'undefined') {
			console.log(playing);
			playing.guitar.stop();
		}

		var source = context.createBufferSource();
		source.buffer = buffer;
		source.connect(context.destination);
		source.start(time);

		playing.guitar = source;
	}

};


//create a new instance of shake.js.
var myShakeEvent = new Shake({
    threshold: 1 // optional shake strength threshold
});
var myShakeTimer,
    myShakeInterval;
var shakeCounter = 0;


// Global Vars
var context,
	bufferLoader;

var sources = new Array();
var playing = {};

// Init App
app.initialize();



